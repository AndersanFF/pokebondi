package mypokemons;
import mymoves.Amnesia;
import mymoves.Bulldoze;
import mymoves.Double_team;
import ru.ifmo.se.pokemon.Type;

public class Piloswine extends Swinub{
    public Piloswine(String name, int level){
        super(name, level);
        super.setType(Type.ICE, Type.GROUND);
        super.setStats(100,100,80,60,60,50);
        Amnesia amnesia = new Amnesia(0,0);
        Bulldoze bulldoze = new Bulldoze(60, 100);
        Double_team double_team = new Double_team(0,0);
        super.setMove(amnesia, bulldoze, double_team);
    }
}
