package mypokemons;


import mymoves.Bulldoze;
import mymoves.Double_team;
import ru.ifmo.se.pokemon.Type;
import ru.ifmo.se.pokemon.Pokemon;
public class Swinub extends Pokemon{
    public Swinub (String name, int level){
        super(name,level);
        super.setType(Type.ICE, Type.GROUND);
        super.setStats(50,50,40,30,30,50);
        Double_team double_team = new Double_team(0,0);
        Bulldoze bulldoze = new Bulldoze(60, 100);

        super.setMove( bulldoze, double_team);


    }
}
